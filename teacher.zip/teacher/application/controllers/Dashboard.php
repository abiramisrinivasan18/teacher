<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include 'common.php';
class Dashboard extends Common {

	public function __construct() {
        parent::__construct();
        
        if (!$this->session->userdata('id')) {
            redirect('teacher');
        }
    }
	public function index(){				
							$data=array();				
							$data['student_details']=$this->operation->getData(array('id','student_name','subject','marks'),'student_data',array('status'=>1));
                            $data['parent_function']=$this;
							$this->load->view('dashboard',$data);
						
}
}
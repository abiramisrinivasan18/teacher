<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include 'common.php';
class Teacher extends Common {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	
	public function index()
	{
		$this->load->view('login');
	}
	public function login(){
				$this->form_validation->set_rules('username','User Name','trim|required');
				$this->form_validation->set_rules('password','Password','required');
				
				if($this->form_validation->run()==FALSE){
					
							$this->load->view('login');
				}
				else
				{
					$username = $this->input->post('username');
					$password = $this->input->post('password');
					
					$user = $this->operation->getData(array('id','teacher_name','teacher_password'),'teacher_login',array('teacher_status'=>1,'teacher_username'=>$username));
					if($user->num_rows()>0){
						$user=$user->row();
						if($user->teacher_password==md5($password)){						
							$this->session->set_userdata('id',$user->id);							
							redirect('teacher-dashboard');
							
						}else{
							
							$info="Incorrect Password";
							$data['info']=$info;
							$this->load->view('login',$data);
							
						}
					}
					else{
						
							$info="No account exists with this email!";
							$data['info']=$info;
							$this->load->view('login',$data);
					}
				}
	}
	public function logout(){
				
			
		$this->session->unset_userdata('id');
		$info="Successfully Logged out!";
		$data['info']=$info;
		$this->load->view('login',$data);
	}
	public function handledata()
	{
		
		$this->form_validation->set_rules('studentname','Name','trim|required');
		$this->form_validation->set_rules('subjectname','Subject','required');
		$this->form_validation->set_rules('mark','Mark','required');

		
		if($this->form_validation->run()==FALSE)
		{
			
		}
		else{
		$data['student_name']=$this->input->post('studentname');
		$data['subject']=$this->input->post('subjectname');
		$data['marks']=$this->input->post('mark');
		$id=$this->encrypt_decrypt('decrypt',$this->input->post('id'));
		if($id>0){//edit
			$data['date_modified']=date('Y-m-d H:i:s');$data['modified_by']=$this->session->userdata('id');
			$status= $this->operation->update('student_data',array('id'=>$id),$data);
			if($status==true)
			{
				 echo "Student Updated Successfully";
				
			}
		}else{//Add 
		$checkifexists=$this->operation->getData(array('id','student_name','subject'),'student_data',array('student_name'=>$this->input->post('studentname'),'subject'=>$this->input->post('subjectname')));
		if($checkifexists->num_rows()>0){//update if similar record found
			$data['date_modified']=date('Y-m-d H:i:s');$data['modified_by']=$this->session->userdata('id');
			$status= $this->operation->update('student_data',array('id'=>$checkifexists->row()->id),$data);
			if($status==true)
			{
				 echo "Student Updated Successfully";
				
			}
		}else{//insert
			$data['date_added']=date('Y-m-d H:i:s');
			$data['added_by']=$this->session->userdata('id');
			$data['status']=1;
		$status= $this->operation->insert('student_data',$data);
		if($status==true)
		{
			 echo "Student Added Successfully";
			
		}
		}
	}
		

		
	}

	
}

public function deletestudent()
	{		
		$id=$this->encrypt_decrypt('decrypt',$this->input->post('id'));
		$this->operation->archive($id);
		$status= $this->operation->deleteStudent($id);
		if($status==true)
		{
			echo "deleted";			
		}
		else
		{
			echo "Error..!";
		}	
	}
}

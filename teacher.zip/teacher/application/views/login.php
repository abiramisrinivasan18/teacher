<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Teacher Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
	<link rel="stylesheet" href="<?= base_url('assets/css/styles.css') ?>">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body class="login-bg">
    <section class="my-5 p-5 login-bg">
	<div class="container text-center">
  <div class="row justify-content-md-center">
    <h1 class="text-ceter mb-5 text-title">tailwebs.</h1>
    <div class="col-md-auto login-container-bg p-5">
	<form action="<?=base_url('teacher/login');?>" method="post">
	<div class="mb-3 text-start">
	<label for="username" class="form-label ">Username</label>
	<input type="text" class="form-control" id="username" name="username" placeholder="">
	<?=@form_error("username");?>
	</div>
	<div class="mb-3 text-start">
	<label for="password" class="form-label ">Password</label>
	<div class="input-group">
	<input type="password" class="form-control" id="password" name="password" placeholder="">
	<button class="btn btn-outline-secondary" type="button" id="button-addon2"><i class="fa fa-eye toggle-password"></i></button>
	</div>
	<?=@form_error("password");?>
	</div>
	<div class="mb-3">
		<button class="btn btn-sm bg-black">Login</button>
	</div>
	<?php if(@$info){?>
		<div class="mb-3">
		<p class="text-center text-warning"><?=$info;?></p>
	</div>
		<?php }?>
  </form>
    </div>
    
  </div>
 
</div>
	</section>
	<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
	<script>
  $("body").on('click', '.toggle-password', function() {
  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $("#password");
  if (input.attr("type") === "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }

});
	</script>
  </body>
</html>
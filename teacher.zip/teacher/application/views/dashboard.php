<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Students - Teacher Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/c08dc256af.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?= base_url('assets/css/styles.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.12.4/dist/sweetalert2.all.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.12.4/dist/sweetalert2.min.css" rel="stylesheet">
  </head>
  <body>
<header>
<nav class="navbar navbar-expand-lg bg-white">
  <div class="container-fluid">
    <a class="navbar-brand text-title" href="#">tailwebs.</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav me-2" >
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?=base_url('log-out')?>">Logout</a>
        </li>
        
       
      </ul>
    </div>
  </div>
</nav>
</header>
  <section class="dashboard-bg">
  <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Subject</th>
      <th scope="col">Mark</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
<?php $i=0;
if($student_details->num_rows()>0){ 
foreach($student_details->result() as $student){
  ++$i;
    $id=$parent_function->encrypt_decrypt("encrypt",$student->id);
    ?>
    <tr>
      <th scope="row"><?=$i;?></th>
      <td><?=$student->student_name;?></td>
      <td><?=$student->subject;?></td>
      <td><?=$student->marks;?></td>
      <td>
      <div class="btn-group">
  <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
  
  </button>
  <ul class="dropdown-menu">
  <li><a class="dropdown-item" href="javascript:void(0);" onclick="edit('<?=$student->student_name;?>','<?=$student->subject;?>','<?=$student->marks;?>','<?=$id;?>')"> Edit</a></li>
  <li><a class="dropdown-item" href="javascript:void(0);" onclick="student_delete('<?=$id;?>')">Delete</a></li>
  </ul>
</div>
        </td>
    </tr>
    <?php
}}else{?>
 <tr>
      
      <td colspan="5" class="text-center">No Student Added yet..!</td>
</tr><?php } ?>
</tbody>
</table>

<button class="btn btn-sm bg-black p-2 m-5" onclick="add()" > Add</button>
    <!-- Modal -->
<div class="modal fade" id="staticBackdrop"  data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
     
      <div class="modal-body">
       <form action="<?=base_url('save');?>" id="modalform" method="post" >
       <div class="mb-3">
          <label for="forName" class="form-label">Name</label>
          <div class="input-group mb-3">
          <span class="input-group-text"><i class="fa-regular fa-user"></i></span>
          <input type="text" class="form-control" id="forName" name="studentname" placeholder="Enter Student Name" id="studentname">
          </div>
       </div>
       
       <div class="mb-3">
          <label for="forSubjectName" class="form-label">Subject</label>
          <div class="input-group mb-3">
          <span class="input-group-text"></span>
          <input type="text" class="form-control" id="forSubjectName" name="subjectname" placeholder="Enter Subject Name"  value="">
          </div>
       </div>

       <div class="mb-3">
          <label for="forMark" class="form-label">Mark</label>
          <div class="input-group mb-3">
          <span class="input-group-text"><i class="fa-regular fa-bookmark"></i></span>
          <input type="text" class="form-control" id="forMark" name="mark" placeholder="Enter Marks" id="mark">
          </div>
       </div>
       <input type="hidden" name="id" id="sid">
      
      </div>
      <div class="modal-footer">        
        <button type="submit" class="btn btn-primary" id="modalbutton">Add</button> </form>
      </div>
    </div>
  </div>
</div>


<!-- edit modal -->
  </section>
  <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script>
      function add(){clear(); $("#modalbutton").html('Add');
        $('#staticBackdrop').modal('show');}
      function clear(){
        $("#forName").val('');
        $("#forSubjectName").val('');
        $("#forMark").val('');
        $("#sid").val('');
      }
      function edit(name,subject,mark,id){
        clear();
        $("#forName").val(name);
        $("#forSubjectName").val(subject);
        $("#forMark").val(mark);
        $("#sid").val(id);
        $("#modalbutton").html('Update');
        $('#staticBackdrop').modal('show');
        
      }
      function student_delete(id){
        Swal.fire({
        title: "Do you want to delete student?",  
        showCancelButton: true,
        confirmButtonText: "Delete",  
        }).then((result) => {  
        if (result.isConfirmed) {      
          $.ajax({
            url:"<?=base_url('delete-student')?>",    //the page containing php script
            type: "post",    //request type,            
            data: {id},
            success:function(result){
               if(result="deleted"){
                Swal.fire({
                title: "Student Deleted Successfully", 
                confirmButtonText: "OK"  
              }).then((result) => {
                
                if (result.isConfirmed) {
                  location.reload();
                } 
              });             
               }else{
                Swal.fire({
                title: "Error..!Try Again..!!",                
                icon: "warning"
              });
               } 
            }
        });
        }
      });
      }


      $("#modalform").submit(function(e) {
      e.preventDefault();
      var form = $(this);
      var actionUrl = form.attr('action');
      $.ajax({
          type: "POST",
          url: actionUrl,
          data: form.serialize(), // serializes the form's elements.
          success: function(data)
          {
          Swal.fire({
          title: data, 
          confirmButtonText: "OK"  
          }).then((result) => {
          if (result.isConfirmed) {
                  location.reload();
                } 
              });       
            }
      });
});
    </script>
  </body>
</html>
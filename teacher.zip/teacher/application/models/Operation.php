<?php
class Operation extends CI_model
{
    function insert($tabel,$data)
    {
        return $this->db->insert($tabel,$data);        
    }

    function update($table,$condion,$data)
    {
        $this->db->set($data);
        $this->db->where($condion);
        return $this->db->update($table);        
    }
    
    function getData($select,$table,$condion)
    {
        if($select){
            $this->db->select($select);
        }else{
            $this->db->select('*');
        }        
        $this->db->from($table);
        $this->db->where($condion);

        return $this->db->get();
    }

    function deleteStudent($id)
    {
        $this->db->where('id',$id);
        return  $this->db->delete('student_data');        
    }  
    public function archive($id){
        $this->db->query("INSERT INTO archive_student_data (SELECT * FROM student_data WHERE id='$id')");
    } 
}

?>
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2024 at 02:45 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teacher`
--

-- --------------------------------------------------------

--
-- Table structure for table `archive_student_data`
--

CREATE TABLE `archive_student_data` (
  `id` int(11) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `marks` int(5) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `added_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `archive_student_data`
--

INSERT INTO `archive_student_data` (`id`, `student_name`, `subject`, `marks`, `status`, `added_by`, `date_added`, `modified_by`, `date_modified`) VALUES
(13, 'Maha', 'Tamil', 80, 1, 1, '2024-08-19 14:26:17', 0, '0000-00-00 00:00:00'),
(10, 'srini', 'Maths', 100, 1, 1, '2024-08-19 14:24:27', 0, '0000-00-00 00:00:00'),
(11, 'sri', 'Chemistry', 100, 1, 1, '2024-08-19 14:25:02', 0, '0000-00-00 00:00:00'),
(12, 'siva', 'Maths', 90, 1, 1, '2024-08-19 14:25:19', 1, '2024-08-19 14:25:53'),
(16, 'Hema', 'Maths', 100, 1, 1, '2024-08-19 14:36:13', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `student_data`
--

CREATE TABLE `student_data` (
  `id` int(11) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `marks` int(5) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `added_by` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_data`
--

INSERT INTO `student_data` (`id`, `student_name`, `subject`, `marks`, `status`, `added_by`, `date_added`, `modified_by`, `date_modified`) VALUES
(14, 'srini', 'Chemistry', 80, 1, 1, '2024-08-19 14:35:33', 1, '2024-08-19 14:36:52'),
(15, 'Siva', 'Maths', 100, 1, 1, '2024-08-19 14:35:49', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_login`
--

CREATE TABLE `teacher_login` (
  `id` int(11) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `teacher_username` varchar(30) NOT NULL,
  `teacher_password` text NOT NULL,
  `teacher_status` tinyint(4) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_login`
--

INSERT INTO `teacher_login` (`id`, `teacher_name`, `teacher_username`, `teacher_password`, `teacher_status`, `date_added`, `date_modified`) VALUES
(1, 'Srinivasan', 'srini', 'e10adc3949ba59abbe56e057f20f883e', 1, '2024-08-17 04:15:08', '2024-08-17 04:15:08'),
(2, 'Siva', 'test', '827ccb0eea8a706c4c34a16891f84e7b', 1, '2024-08-17 04:15:08', '2024-08-17 04:15:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_data`
--
ALTER TABLE `student_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_login`
--
ALTER TABLE `teacher_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_data`
--
ALTER TABLE `student_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `teacher_login`
--
ALTER TABLE `teacher_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

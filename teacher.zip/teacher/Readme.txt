Database Name is : teacher
user name: root
password : 
host:localhost


*************
Teacher Login Detail

User Name : srini
Password : 123456

******
SQL file attached 